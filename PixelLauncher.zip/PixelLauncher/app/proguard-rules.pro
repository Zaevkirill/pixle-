# Compose и AndroidX несут собственные consumer-rules. Свой код не трогаем.
-keep class com.example.pixellauncher.** { *; }
