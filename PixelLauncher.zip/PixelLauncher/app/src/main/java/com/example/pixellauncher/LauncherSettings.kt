package com.example.pixellauncher

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import kotlin.reflect.KProperty

class PrefState<T : Any>(
    private val sp: SharedPreferences,
    private val key: String,
    default: T
) {
    private val state = mutableStateOf(read(default))

    operator fun getValue(thisRef: Any?, property: KProperty<*>): T = state.value

    operator fun setValue(thisRef: Any?, property: KProperty<*>, value: T) {
        state.value = value
        val e = sp.edit()
        when (value) {
            is Boolean -> e.putBoolean(key, value)
            is Int -> e.putInt(key, value)
            is Float -> e.putFloat(key, value)
            is String -> e.putString(key, value)
        }
        e.apply()
    }

    @Suppress("UNCHECKED_CAST")
    private fun read(d: T): T = when (d) {
        is Boolean -> sp.getBoolean(key, d)
        is Int -> sp.getInt(key, d)
        is Float -> sp.getFloat(key, d)
        is String -> sp.getString(key, d) ?: d
        else -> d
    } as T
}

/** Иконка на рабочем столе: страница, строка, столбец. */
data class HomeEntry(val key: String, val page: Int, val row: Int, val col: Int)

/** Раскладка, прочитанная из системного лаунчера. */
class ImportedLayout(val home: List<HomeEntry>, val dock: List<String>, val cols: Int, val rows: Int)

class LauncherSettings private constructor(ctx: Context) {
    private val sp = ctx.getSharedPreferences("launcher_prefs", Context.MODE_PRIVATE)

    var showLabelsHome by PrefState(sp, "labelsHome", true)
    var showLabelsDrawer by PrefState(sp, "labelsDrawer", true)
    var iconScale by PrefState(sp, "iconScale", 1f)
    var gridPreset by PrefState(sp, "gridPreset", 0)
    var iconShape by PrefState(sp, "iconShape", 0)           // 0 круг, 1 сквиркл, 2 скруглённый квадрат
    var allOnHome by PrefState(sp, "allOnHome", true)        // все приложения лежат на рабочем столе
    var iconPack by PrefState(sp, "iconPack", "")
    var themedIcons by PrefState(sp, "themedIcons", false)

    var lockEnabled by PrefState(sp, "lockEnabled", false)
    var clockWeight by PrefState(sp, "clockWeight", 300)
    var clockSize by PrefState(sp, "clockSize", 96)
    var clockHeight by PrefState(sp, "clockHeight", 1f)
    var clockStyle by PrefState(sp, "clockStyle", 1)
    var clockColor by PrefState(sp, "clockColor", 0)

    var homeItems by PrefState(sp, "homeItems2", "")         // строки: ключ|страница|строка|столбец
    var dockItems by PrefState(sp, "dockItems", "")
    var initialized by PrefState(sp, "initialized2", false)

    val cols: Int get() = GRIDS[gridPreset.coerceIn(0, GRIDS.lastIndex)].first
    val rows: Int get() = GRIDS[gridPreset.coerceIn(0, GRIDS.lastIndex)].second

    fun dockList(): List<String> = dockItems.split("\n").filter { it.isNotBlank() }

    fun homeEntries(): List<HomeEntry> = homeItems.split("\n").mapNotNull { line ->
        val p = line.split("|")
        if (p.size != 4) {
            null
        } else {
            val pg = p[1].toIntOrNull()
            val r = p[2].toIntOrNull()
            val c = p[3].toIntOrNull()
            if (pg == null || r == null || c == null) null else HomeEntry(p[0], pg, r, c)
        }
    }

    private fun saveHome(list: List<HomeEntry>) {
        homeItems = list.joinToString("\n") { "${it.key}|${it.page}|${it.row}|${it.col}" }
    }

    private fun freeSlot(used: Set<Triple<Int, Int, Int>>): Triple<Int, Int, Int> {
        for (page in 0 until 1000) {
            for (r in 0 until rows) {
                for (c in 0 until cols) {
                    val t = Triple(page, r, c)
                    if (t !in used) return t
                }
            }
        }
        return Triple(1000, 0, 0)
    }

    fun addHome(key: String) {
        val e = homeEntries()
        if (e.any { it.key == key }) return
        val used = e.map { Triple(it.page, it.row, it.col) }.toHashSet()
        val t = freeSlot(used)
        saveHome(e + HomeEntry(key, t.first, t.second, t.third))
    }

    fun removeHome(key: String) {
        saveHome(homeEntries().filter { it.key != key })
    }

    fun addDock(key: String) {
        val l = dockList()
        if (key !in l && l.size < 5) dockItems = (l + key).joinToString("\n")
    }

    fun removeDock(key: String) {
        dockItems = dockList().filter { it != key }.joinToString("\n")
    }

    /**
     * Приводит рабочий стол в порядок: убирает удалённые приложения, дубликаты и иконки вне сетки,
     * а при включённом «все приложения на рабочем столе» добавляет недостающие в свободные ячейки.
     */
    fun syncHome(apps: List<AppInfo>) {
        if (apps.isEmpty()) return
        val valid = apps.map { it.key }.toHashSet()
        val dock = dockList().toHashSet()
        val seen = HashSet<String>()
        val keep = ArrayList<HomeEntry>()
        val toPlace = ArrayList<String>()
        for (e in homeEntries()) {
            if (e.key !in valid || e.key in dock || !seen.add(e.key)) continue
            if (e.row < rows && e.col < cols) keep.add(e) else toPlace.add(e.key)
        }
        if (allOnHome) {
            for (a in apps) if (a.key !in seen && a.key !in dock) toPlace.add(a.key)
        }
        val used = keep.map { Triple(it.page, it.row, it.col) }.toHashSet()
        val result = ArrayList<HomeEntry>(keep)
        for (k in toPlace) {
            val t = freeSlot(used)
            used.add(t)
            result.add(HomeEntry(k, t.first, t.second, t.third))
        }
        saveHome(result)
    }

    fun applyImport(imp: ImportedLayout) {
        val fit = GRIDS.withIndex()
            .filter { it.value.first >= imp.cols && it.value.second >= imp.rows }
            .minByOrNull { it.value.first * it.value.second }
        gridPreset = fit?.index ?: GRIDS.lastIndex
        saveHome(imp.home)
        dockItems = imp.dock.take(5).joinToString("\n")
    }

    companion object {
        /** Доступные сетки: столбцы × строки. */
        val GRIDS = listOf(4 to 5, 5 to 5, 5 to 6, 4 to 6, 6 to 6)

        @Volatile
        private var instance: LauncherSettings? = null

        fun get(ctx: Context): LauncherSettings =
            instance ?: synchronized(this) {
                instance ?: LauncherSettings(ctx.applicationContext).also { instance = it }
            }
    }
}
