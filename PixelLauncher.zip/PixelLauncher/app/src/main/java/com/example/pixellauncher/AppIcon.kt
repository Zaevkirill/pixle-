package com.example.pixellauncher

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Image
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Лёгкая иконка: без отдельного меню на каждую иконку, пружина нажатия читается только в фазе рисования,
 * меню показывается одним общим диалогом (см. Home.kt).
 */
@Composable
fun AppIcon(
    app: AppInfo,
    icons: IconLoader,
    s: LauncherSettings,
    showLabel: Boolean,
    labelColor: Color,
    modifier: Modifier = Modifier,
    onLongClick: () -> Unit,
    onClick: () -> Unit
) {
    val density = LocalDensity.current
    val sizeDp = (56f * s.iconScale).dp
    val px = with(density) { sizeDp.roundToPx() }
    val bmp by produceState<ImageBitmap?>(null, app.key, px, icons.version) {
        value = icons.get(app, px)
    }

    var pressed by remember { mutableStateOf(false) }
    val scale = animateFloatAsState(
        targetValue = if (pressed) 0.86f else 1f,
        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
        label = "iconPress"
    )
    val click by rememberUpdatedState(onClick)
    val longClick by rememberUpdatedState(onLongClick)

    Box(
        modifier
            .graphicsLayer { scaleX = scale.value; scaleY = scale.value }
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        tryAwaitRelease()
                        pressed = false
                    },
                    onLongPress = { longClick() },
                    onTap = { click() }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            val b = bmp
            if (b != null) Image(b, app.label, Modifier.size(sizeDp)) else Spacer(Modifier.size(sizeDp))
            if (showLabel) {
                Text(
                    app.label,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    style = TextStyle(
                        color = labelColor,
                        fontSize = 12.sp,
                        textAlign = TextAlign.Center,
                        shadow = if (labelColor == Color.White) Shadow(Color(0x88000000), Offset(0f, 2f), 4f) else null
                    ),
                    modifier = Modifier.padding(top = 4.dp, start = 2.dp, end = 2.dp)
                )
            }
        }
    }
}
