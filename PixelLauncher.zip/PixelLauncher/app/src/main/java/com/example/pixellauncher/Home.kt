@file:OptIn(ExperimentalFoundationApi::class)

package com.example.pixellauncher

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Velocity
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.yield

enum class MenuSrc { HOME, DOCK, DRAWER }

private class MenuState(val app: AppInfo, val src: MenuSrc)

@Composable
fun LauncherRoot(s: LauncherSettings, repo: AppRepository, icons: IconLoader, homeSignal: Int) {
    val ctx = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val screenH = with(density) { LocalConfiguration.current.screenHeightDp.dp.toPx() }

    // progress читается только в фазе рисования / в жестах — рабочий стол не перекомпонуется на каждом кадре
    val progress = remember { mutableFloatStateOf(0f) }
    var job by remember { mutableStateOf<Job?>(null) }
    var showSettings by remember { mutableStateOf(false) }
    var searchSignal by remember { mutableIntStateOf(0) }
    var autoFocus by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf<MenuState?>(null) }
    val drawerVisible by remember { derivedStateOf { progress.floatValue > 0f } }
    val dimActive by remember { derivedStateOf { progress.floatValue > 0.02f } }

    val apps = repo.apps
    val byKey = remember(apps) { apps.associateBy { it.key } }

    fun settle(target: Float) {
        job?.cancel()
        job = scope.launch {
            animate(
                progress.floatValue, target,
                animationSpec = spring(dampingRatio = 0.85f, stiffness = Spring.StiffnessMediumLow)
            ) { v, _ -> progress.floatValue = v }
        }
    }

    fun drag(delta: Float) {
        job?.cancel()
        progress.floatValue = (progress.floatValue + delta).coerceIn(0f, 1f)
    }

    val connection = remember {
        object : NestedScrollConnection {
            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val p = progress.floatValue
                if (available.y < 0f && p > 0f && p < 1f) {
                    drag(-available.y / screenH)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                if (available.y > 0f && source == NestedScrollSource.Drag) {
                    drag(-available.y / screenH)
                    return Offset(0f, available.y)
                }
                return Offset.Zero
            }

            override suspend fun onPostFling(consumed: Velocity, available: Velocity): Velocity {
                val p = progress.floatValue
                if (p > 0.001f && p < 0.999f) settle(if (p > 0.8f) 1f else 0f)
                return Velocity.Zero
            }
        }
    }

    // Форма иконок / пак / тема
    LaunchedEffect(s.iconPack, s.themedIcons, s.iconShape, scheme.primaryContainer, scheme.onPrimaryContainer) {
        icons.configure(
            s.iconPack, s.themedIcons, s.iconShape,
            scheme.primaryContainer.toArgb(), scheme.onPrimaryContainer.toArgb()
        )
    }

    // Фоновая подгрузка всех иконок в кэш — потом прокрутка без задержек
    val iconPx = with(density) { (56f * s.iconScale).dp.roundToPx() }
    LaunchedEffect(apps, icons.version, iconPx) {
        withContext(Dispatchers.IO) {
            for (a in apps) {
                icons.get(a, iconPx)
                yield()
            }
        }
    }

    // Первый запуск: пробуем скопировать раскладку системного лаунчера, иначе — по алфавиту
    LaunchedEffect(apps) {
        if (apps.isNotEmpty() && !s.initialized) {
            val imp = withContext(Dispatchers.IO) {
                runCatching { LayoutImporter.load(ctx, apps) }.getOrNull()
            }
            if (imp != null) s.applyImport(imp) else s.dockItems = repo.defaultDock(apps).joinToString("\n")
            s.syncHome(apps)
            s.initialized = true
        }
    }

    // Поддерживаем порядок: новые приложения, смена сетки, док
    LaunchedEffect(apps, s.gridPreset, s.allOnHome, s.dockItems, s.initialized) {
        if (s.initialized) s.syncHome(apps)
    }

    LaunchedEffect(drawerVisible) {
        if (!drawerVisible) autoFocus = false
    }

    LaunchedEffect(homeSignal) {
        showSettings = false
        if (progress.floatValue > 0f) settle(0f)
    }

    BackHandler(enabled = showSettings || drawerVisible) {
        if (showSettings) showSettings = false else settle(0f)
    }

    Box(Modifier.fillMaxSize()) {
        HomeScreen(
            s = s,
            icons = icons,
            byKey = byKey,
            onDrag = { dy -> drag(-dy / screenH) },
            onDragEnd = { settle(if (progress.floatValue > 0.2f) 1f else 0f) },
            onSearch = { autoFocus = true; searchSignal++; settle(1f) },
            onSettings = { showSettings = true },
            onMenu = { app, src -> menu = MenuState(app, src) },
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { alpha = 1f - progress.floatValue * 0.9f }
        )

        if (dimActive) {
            Box(
                Modifier
                    .fillMaxSize()
                    .clickable(
                        interactionSource = remember { MutableInteractionSource() },
                        indication = null
                    ) { settle(0f) }
            )
        }

        // Меню приложений создаётся только когда открыто — экономит память и CPU
        if (drawerVisible) {
            AppDrawer(
                apps = apps,
                icons = icons,
                s = s,
                autoFocus = autoFocus,
                connection = connection,
                onMenu = { app -> menu = MenuState(app, MenuSrc.DRAWER) },
                onClose = { settle(0f) },
                modifier = Modifier
                    .fillMaxSize()
                    .graphicsLayer { translationY = (1f - progress.floatValue) * screenH }
            )
        }

        AnimatedVisibility(
            visible = showSettings,
            enter = slideInVertically(
                animationSpec = spring(stiffness = Spring.StiffnessMediumLow)
            ) { it } + fadeIn(),
            exit = slideOutVertically { it } + fadeOut()
        ) {
            SettingsScreen(s = s, apps = apps, onBack = { showSettings = false })
        }

        menu?.let { m ->
            AppMenuDialog(app = m.app, src = m.src, s = s, onDismiss = { menu = null })
        }
    }
}

@Composable
private fun AppMenuDialog(app: AppInfo, src: MenuSrc, s: LauncherSettings, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val actions = buildList<Pair<String, () -> Unit>> {
        if (src == MenuSrc.HOME && !s.allOnHome) add("Убрать с рабочего стола" to { s.removeHome(app.key) })
        if (src == MenuSrc.DOCK) add("Убрать из дока" to { s.removeDock(app.key) })
        if (src == MenuSrc.DRAWER && !s.allOnHome) add("На рабочий стол" to { s.addHome(app.key) })
        if (src != MenuSrc.DOCK) add("В док" to { s.addDock(app.key) })
        add("О приложении" to { openAppInfo(ctx, app) })
        add("Удалить" to { uninstallApp(ctx, app) })
    }
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(28.dp),
            color = scheme.surface,
            contentColor = scheme.onSurface,
            tonalElevation = 6.dp
        ) {
            Column(Modifier.padding(vertical = 12.dp)) {
                Text(
                    app.label,
                    style = MaterialTheme.typography.titleMedium,
                    modifier = Modifier.padding(horizontal = 24.dp, vertical = 8.dp)
                )
                actions.forEach { (title, action) ->
                    Text(
                        title,
                        Modifier
                            .fillMaxWidth()
                            .clickable { onDismiss(); action() }
                            .padding(horizontal = 24.dp, vertical = 14.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun HomeScreen(
    s: LauncherSettings,
    icons: IconLoader,
    byKey: Map<String, AppInfo>,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    onSearch: () -> Unit,
    onSettings: () -> Unit,
    onMenu: (AppInfo, MenuSrc) -> Unit,
    modifier: Modifier = Modifier
) {
    val ctx = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val cols = s.cols
    val rows = s.rows

    val entries = remember(s.homeItems, byKey, cols, rows) {
        s.homeEntries().filter { byKey.containsKey(it.key) && it.row < rows && it.col < cols }
    }
    val grid = remember(entries) { entries.associateBy { Triple(it.page, it.row, it.col) } }
    val pageCount = (entries.maxOfOrNull { it.page } ?: 0) + 1
    val dock = s.dockList().mapNotNull { byKey[it] }
    val pager = rememberPagerState(pageCount = { pageCount })

    Column(
        modifier
            .systemBarsPadding()
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragEnd = { onDragEnd() },
                    onDragCancel = { onDragEnd() }
                ) { _, dy -> onDrag(dy) }
            }
    ) {
        AtAGlance(Modifier.padding(start = 24.dp, top = 20.dp, bottom = 8.dp))

        HorizontalPager(
            state = pager,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .pointerInput(Unit) { detectTapGestures(onLongPress = { onSettings() }) }
        ) { page ->
            Column(Modifier.fillMaxSize().padding(horizontal = 8.dp)) {
                for (r in 0 until rows) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (c in 0 until cols) {
                            Box(
                                Modifier.weight(1f).fillMaxHeight(),
                                contentAlignment = Alignment.Center
                            ) {
                                val app = grid[Triple(page, r, c)]?.let { byKey[it.key] }
                                if (app != null) {
                                    AppIcon(
                                        app, icons, s, s.showLabelsHome, Color.White,
                                        onLongClick = { onMenu(app, MenuSrc.HOME) }
                                    ) { launchApp(ctx, app) }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (pageCount > 1) {
            Row(Modifier.align(Alignment.CenterHorizontally).padding(vertical = 6.dp)) {
                repeat(pageCount) { i ->
                    val active = pager.currentPage == i
                    val w by animateDpAsState(
                        targetValue = if (active) 18.dp else 6.dp,
                        animationSpec = spring(Spring.DampingRatioMediumBouncy, Spring.StiffnessMedium),
                        label = "dot"
                    )
                    Box(
                        Modifier
                            .padding(horizontal = 3.dp)
                            .height(6.dp)
                            .width(w)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = if (active) 0.95f else 0.5f))
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().heightIn(min = 72.dp).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            dock.forEach { app ->
                AppIcon(
                    app, icons, s, false, Color.White,
                    onLongClick = { onMenu(app, MenuSrc.DOCK) }
                ) { launchApp(ctx, app) }
            }
        }

        Row(
            Modifier
                .fillMaxWidth()
                .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 12.dp)
                .height(52.dp)
                .clip(CircleShape)
                .background(scheme.surface.copy(alpha = 0.92f))
                .clickable(onClick = onSearch)
                .padding(horizontal = 18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Search, contentDescription = null, tint = scheme.onSurfaceVariant)
            Spacer(Modifier.width(12.dp))
            Text("Поиск приложений", color = scheme.onSurfaceVariant, fontSize = 16.sp)
        }
    }
}
