package com.example.pixellauncher

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri

private class Cell(val app: AppInfo, val screen: Int, val x: Int, val y: Int)

/**
 * Пытается прочитать раскладку рабочего стола системного лаунчера (таблица favorites его провайдера).
 * Работает только если сам лаунчер разрешает чтение сторонним приложениям — это зависит от прошивки.
 */
object LayoutImporter {
    private val authorities = listOf(
        "com.android.launcher3.settings",
        "com.google.android.apps.nexuslauncher.settings",
        "com.sec.android.app.launcher.settings",
        "com.miui.home.launcher.settings",
        "com.huawei.android.launcher.settings",
        "net.oneplus.launcher.settings",
        "com.android.launcher.settings",
        "com.android.launcher2.settings"
    )

    fun load(ctx: Context, apps: List<AppInfo>): ImportedLayout? {
        val pm = ctx.packageManager
        val homePkg = pm.resolveActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME),
            PackageManager.MATCH_DEFAULT_ONLY
        )?.activityInfo?.packageName
        val list = (listOfNotNull(homePkg?.let { "$it.settings" }) + authorities).distinct()
        for (a in list) {
            val r = runCatching { read(ctx, a, apps) }.getOrNull()
            if (r != null) return r
        }
        return null
    }

    private fun read(ctx: Context, authority: String, apps: List<AppInfo>): ImportedLayout? {
        val byComp = apps.associateBy { it.key }
        val firstByPkg = HashMap<String, AppInfo>()
        for (a in apps) firstByPkg.putIfAbsent(a.pkg, a)

        fun resolve(s: String?): AppInfo? {
            if (s.isNullOrEmpty()) return null
            val comp = runCatching { Intent.parseUri(s, 0).component }.getOrNull() ?: return null
            return byComp["${comp.packageName}/${comp.className}"] ?: firstByPkg[comp.packageName]
        }

        val desk = ArrayList<Cell>()
        val hot = ArrayList<Cell>()
        val cursor = ctx.contentResolver.query(
            Uri.parse("content://$authority/favorites"),
            arrayOf("intent", "container", "screen", "cellX", "cellY", "itemType"),
            null, null, null
        ) ?: return null

        cursor.use { c ->
            val iI = c.getColumnIndexOrThrow("intent")
            val iC = c.getColumnIndexOrThrow("container")
            val iS = c.getColumnIndexOrThrow("screen")
            val iX = c.getColumnIndexOrThrow("cellX")
            val iY = c.getColumnIndexOrThrow("cellY")
            val iT = c.getColumnIndexOrThrow("itemType")
            while (c.moveToNext()) {
                if (c.getInt(iT) != 0) continue
                val app = resolve(c.getString(iI)) ?: continue
                val cell = Cell(app, c.getInt(iS), c.getInt(iX), c.getInt(iY))
                val container = c.getInt(iC)
                if (container == -100) desk.add(cell) else if (container == -101) hot.add(cell)
            }
        }
        if (desk.isEmpty() && hot.isEmpty()) return null

        val screens = desk.map { it.screen }.distinct().sorted()
        val home = desk.distinctBy { it.app.key }
            .map { HomeEntry(it.app.key, screens.indexOf(it.screen), it.y, it.x) }
        val dock = hot.sortedWith(compareBy({ it.screen }, { it.x })).map { it.app.key }.distinct()
        val cols = (desk.maxOfOrNull { it.x } ?: 0) + 1
        val rows = (desk.maxOfOrNull { it.y } ?: 0) + 1
        return ImportedLayout(home, dock, cols, rows)
    }
}
